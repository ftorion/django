class MyMixin(object):
    mixin_prop = " "

    def get_prop(self):
        return self.mixin_prop.upper()
